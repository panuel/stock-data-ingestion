import pika
import json
import psycopg2

RABBITMQ_HOST = "rabbitmq"
QUEUE_NAME = "stock_data_queue"
DB_HOST = "db"
DB_NAME = "stock_data"
DB_USER = "postgres"
DB_PASSWORD = "password"

# Database setup
def save_to_db(data):
    conn = psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )
    cursor = conn.cursor()

    # Create table if not exists
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS stock_data (
        timestamp TIMESTAMP PRIMARY KEY,
        open FLOAT,
        high FLOAT,
        low FLOAT,
        close FLOAT,
        volume FLOAT
    );
    """)

    # Insert data
    cursor.execute("""
    INSERT INTO stock_data (timestamp, open, high, low, close, volume)
    VALUES (%s, %s, %s, %s, %s, %s)
    ON CONFLICT (timestamp) DO NOTHING;
    """, (
        data["timestamp"],
        data["open"],
        data["high"],
        data["low"],
        data["close"],
        data["volume"]
    ))
    conn.commit()
    cursor.close()
    conn.close()

# RabbitMQ setup
def callback(ch, method, properties, body):
    message = json.loads(body)
    print(f"Received: {message}")
    save_to_db(message)

connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST))
channel = connection.channel()
channel.queue_declare(queue=QUEUE_NAME)
channel.basic_consume(queue=QUEUE_NAME, on_message_callback=callback, auto_ack=True)

print("Waiting for messages. To exit press CTRL+C")
channel.start_consuming()