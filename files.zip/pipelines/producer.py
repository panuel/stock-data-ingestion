import pika
import requests
import json
import time

RABBITMQ_HOST = "rabbitmq"
QUEUE_NAME = "stock_data_queue"

# RabbitMQ setup
connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST))
channel = connection.channel()
channel.queue_declare(queue=QUEUE_NAME)

# Fetch data from API
def fetch_stock_data():
    url = "https://www.alphavantage.co/query"
    params = {
        "function": "TIME_SERIES_INTRADAY",
        "symbol": "AAPL",
        "interval": "1min",
        "apikey": "your_api_key"
    }
    response = requests.get(url, params=params)
    data = response.json()
    return data["Time Series (1min)"]

# Push data to RabbitMQ
def push_to_queue(data):
    for timestamp, values in data.items():
        message = json.dumps({
            "timestamp": timestamp,
            "open": values["1. open"],
            "high": values["2. high"],
            "low": values["3. low"],
            "close": values["4. close"],
            "volume": values["5. volume"]
        })
        channel.basic_publish(exchange='', routing_key=QUEUE_NAME, body=message)
        print(f"Sent: {message}")

if __name__ == "__main__":
    while True:
        try:
            stock_data = fetch_stock_data()
            push_to_queue(stock_data)
            time.sleep(60)  # Fetch data every minute
        except Exception as e:
            print(f"Error: {e}")